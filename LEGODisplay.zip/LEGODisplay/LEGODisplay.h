#ifndef LEGODisplay_H 
#define LEGODisplay_H

#include <string.h>
#if ARDUINO >= 100 
	#include "Arduino.h" 
#else 
	#include "WProgram.h" 
#endif 

#include "LEGOLCD.h"
#include <inttypes.h>
#include <Print.h>

#include "I2CIO.h"
#include "LCD.h"

LEGOLCD lcd1;

void initDisplay(int numChar, int numLine){
	lcd1.begin(numChar,numLine);         // initialize the lcd for 20 chars 4 lines and turn on backlight
  }
void setDisplayCursor(int numChar, int numLine ){  
  lcd1.setCursor(numChar,numLine); //Start at character 4 on line 0
  }
void printDisplay(char *s){ 
  lcd1.print(s);
  }
void clearDisplay(){  
  lcd1.clear();
  }
/***************************************END*****************************/
#endif