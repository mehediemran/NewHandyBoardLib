#include "LEGOmotor.h"



/***********************************************************************
                      motor_1 functions
************************************************************************/
void motor_1_Forward(int speed)
{
      motor_output (MOTOR1_A, HIGH, speed);
      motor_output (MOTOR1_B, LOW, -1);     // -1: no PWM set
}     
void motor_1_Backward(int speed)  
{   
      motor_output (MOTOR1_A, LOW, speed);
      motor_output (MOTOR1_B, HIGH, -1);    // -1: no PWM set
}

void motor_1_Brake(void)
{
      motor_output (MOTOR1_A, LOW, 255); // 255: fully on.
      motor_output (MOTOR1_B, LOW, -1);  // -1: no PWM set
}      

void motor_1_Release(void)
{
      motor_output (MOTOR1_A, LOW, 0);  // 0: output floating.
      motor_output (MOTOR1_B, LOW, -1); // -1: no PWM set
}      

/***********************************************************************
                      motor_2 functions
************************************************************************/
void motor_2_Forward(int speed)
{
      motor_output (MOTOR2_A, HIGH, speed);
      motor_output (MOTOR2_B, LOW, -1);     // -1: no PWM set
}     
void motor_2_Backward(int speed)  
{   
      motor_output (MOTOR2_A, LOW, speed);
      motor_output (MOTOR2_B, HIGH, -1);    // -1: no PWM set
}

void motor_2_Brake(void)
{
      motor_output (MOTOR2_A, LOW, 255); // 255: fully on.
      motor_output (MOTOR2_B, LOW, -1);  // -1: no PWM set
}      

void motor_2_Release(void)
{
      motor_output (MOTOR2_A, LOW, 0);  // 0: output floating.
      motor_output (MOTOR2_B, LOW, -1); // -1: no PWM set
}      
/***********************************************************************
                      motor_3 functions
************************************************************************/
void motor_3_Forward(int speed)
{
      motor_output (MOTOR3_A, HIGH, speed);
      motor_output (MOTOR3_B, LOW, -1);     // -1: no PWM set
}     
void motor_3_Backward(int speed)  
{   
      motor_output (MOTOR3_A, LOW, speed);
      motor_output (MOTOR3_B, HIGH, -1);    // -1: no PWM set
}

void motor_3_Brake(void)
{
      motor_output (MOTOR3_A, LOW, 255); // 255: fully on.
      motor_output (MOTOR3_B, LOW, -1);  // -1: no PWM set
}      

void motor_3_Release(void)
{
      motor_output (MOTOR3_A, LOW, 0);  // 0: output floating.
      motor_output (MOTOR3_B, LOW, -1); // -1: no PWM set
}      
/***********************************************************************
                      motor_4 functions
************************************************************************/
void motor_4_Forward(int speed)
{
      motor_output (MOTOR4_A, HIGH, speed);
      motor_output (MOTOR4_B, LOW, -1);     // -1: no PWM set
}     
void motor_4_Backward(int speed)  
{   
      motor_output (MOTOR4_A, LOW, speed);
      motor_output (MOTOR4_B, HIGH, -1);    // -1: no PWM set
}

void motor_4_Brake(void)
{
      motor_output (MOTOR4_A, LOW, 255); // 255: fully on.
      motor_output (MOTOR4_B, LOW, -1);  // -1: no PWM set
}      

void motor_4_Release(void)
{
      motor_output (MOTOR4_A, LOW, 0);  // 0: output floating.
      motor_output (MOTOR4_B, LOW, -1); // -1: no PWM set
}      




/***********************************************************************
                      motor_output
************************************************************************/

void motor_output (int output, int high_low, int speed)
{
  int motorPWM;

  switch (output)
  {
  case MOTOR1_A:
  case MOTOR1_B:
    motorPWM = MOTOR1_PWM;
    break;
  case MOTOR2_A:
  case MOTOR2_B:
    motorPWM = MOTOR2_PWM;
    break;
  case MOTOR3_A:
  case MOTOR3_B:
    motorPWM = MOTOR3_PWM;
    break;
  case MOTOR4_A:
  case MOTOR4_B:
    motorPWM = MOTOR4_PWM;
    break;
  default:
    // Use speed as error flag, -3333 = invalid output.
    speed = -3333;
    break;
  }

  if (speed != -3333)
  {
    // Set the direction with the shift register 
    // on the MotorShield, even if the speed = -1.
    // In that case the direction will be set, but
    // not the PWM.
    shiftWrite(output, high_low);

    // set PWM only if it is valid
    if (speed >= 0 && speed <= 255)    
    {
      analogWrite(motorPWM, speed);
    }
  }
}

/***********************************************************************
                     shiftWrite
************************************************************************/
// ---------------------------------
// shiftWrite
//
// The parameters are just like digitalWrite().
//
// The output is the pin 0...7 (the pin behind 
// the shift register).
// The second parameter is HIGH or LOW.
//
// There is no initialization function.
// Initialization is automatically done at the first
// time it is used.
//
void shiftWrite(int output, int high_low)
{
  static int latch_copy;
  static int shift_register_initialized = false;

  // Do the initialization on the fly, 
  // at the first time it is used.
  if (!shift_register_initialized)
  {
    // Set pins for shift register to output
    pinMode(MOTORLATCH, OUTPUT);
    pinMode(MOTORENABLE, OUTPUT);
    pinMode(MOTORDATA, OUTPUT);
    pinMode(MOTORCLK, OUTPUT);

    // Set pins for shift register to default value (low);
    digitalWrite(MOTORDATA, LOW);
    digitalWrite(MOTORLATCH, LOW);
    digitalWrite(MOTORCLK, LOW);
    // Enable the shift register, set Enable pin Low.
    digitalWrite(MOTORENABLE, LOW);

    // start with all outputs (of the shift register) low
    latch_copy = 0;

    shift_register_initialized = true;
  }

  // The defines HIGH and LOW are 1 and 0.
  // So this is valid.
  bitWrite(latch_copy, output, high_low);

  // Use the default Arduino 'shiftOut()' function to
  // shift the bits with the MOTORCLK as clock pulse.
  // The 74HC595 shiftregister wants the MSB first.
  // After that, generate a latch pulse with MOTORLATCH.
  shiftOut(MOTORDATA, MOTORCLK, MSBFIRST, latch_copy);
  delayMicroseconds(5);    // For safety, not really needed.
  digitalWrite(MOTORLATCH, HIGH);
  delayMicroseconds(5);    // For safety, not really needed.
  digitalWrite(MOTORLATCH, LOW);
}