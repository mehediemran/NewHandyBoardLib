#ifndef LEGOmotor_H 
#define LEGOmotor_H

#if ARDUINO >= 100 
	#include "Arduino.h" 
#else 
	#include "WProgram.h" 
#endif 

// Arduino pins for the shift register
#define MOTORLATCH 12
#define MOTORCLK 4
#define MOTORENABLE 7
#define MOTORDATA 8

// 8-bit bus after the 74HC595 shift register 
// (not Arduino pins)
// These are used to set the direction of the bridge driver.
#define MOTOR1_A 2
#define MOTOR1_B 3
#define MOTOR2_A 1
#define MOTOR2_B 4
#define MOTOR3_A 5
#define MOTOR3_B 7
#define MOTOR4_A 0
#define MOTOR4_B 6

// Arduino pins for the PWM signals.
#define MOTOR1_PWM 11
#define MOTOR2_PWM 3
#define MOTOR3_PWM 6
#define MOTOR4_PWM 5
#define SERVO1_PWM 10
#define SERVO2_PWM 9

// Codes for the motor function.
#define FORWARD 1
#define BACKWARD 2
#define BRAKE 3
#define RELEASE 4


/***********************************************************************
                      motor_1 functions
************************************************************************/
void motor_1_Forward(int speed);
void motor_1_Backward(int speed);  
void motor_1_Brake(void);
void motor_1_Release(void);
/***********************************************************************
                      motor_2 functions
************************************************************************/
void motor_2_Forward(int speed);
void motor_2_Backward(int speed);  
void motor_2_Brake(void);
void motor_2_Release(void);
/***********************************************************************
                      motor_3 functions
************************************************************************/
void motor_3_Forward(int speed);
void motor_3_Backward(int speed);  
void motor_3_Brake(void);
void motor_3_Release(void);
/***********************************************************************
                      motor_4 functions
************************************************************************/
void motor_4_Forward(int speed);
void motor_4_Backward(int speed);  
void motor_4_Brake(void);
void motor_4_Release(void);

/***********************************************************************
                      motor_output
************************************************************************/

void motor_output (int output, int high_low, int speed);
/***********************************************************************
                     shiftWrite
************************************************************************/
// ---------------------------------
// shiftWrite
//
// The parameters are just like digitalWrite().
//
// The output is the pin 0...7 (the pin behind 
// the shift register).
// The second parameter is HIGH or LOW.
//
// There is no initialization function.
// Initialization is automatically done at the first
// time it is used.
//
void shiftWrite(int output, int high_low);
/***************************************END*****************************/
#endif